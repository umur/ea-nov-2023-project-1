package ea.project.surevy_surveyresponse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurevySurveyresponseApplicationTests {

    @Test
    void contextLoads() {
    }

}
