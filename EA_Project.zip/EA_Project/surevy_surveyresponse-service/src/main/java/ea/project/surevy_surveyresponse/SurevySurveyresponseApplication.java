package ea.project.surevy_surveyresponse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurevySurveyresponseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SurevySurveyresponseApplication.class, args);
    }

}
