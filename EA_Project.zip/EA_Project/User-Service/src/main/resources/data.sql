insert  into role (id,name) values (1,'admin');
insert  into role (id,name) values (2,'student');
insert  into role (id,name) values (3,'faculty');
