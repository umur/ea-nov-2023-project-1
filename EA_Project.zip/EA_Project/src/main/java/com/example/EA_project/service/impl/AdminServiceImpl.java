package com.example.EA_project.service.impl;

import com.example.EA_project.entity.Job;
import com.example.EA_project.service.AdminService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Override
    public void add(Job job) {

    }

    @Override
    public void remove(int id) {

    }

    @Override
    public List<Job> finalAll() {
        return null;
    }

    @Override
    public void update(Job job) {

    }
}
